from distutils.core import setup

setup(name='Ssub', version='0.7',
      py_modules=['termProject', 'graph', 'LineMap', 'RealTimeDv', 'teller2', 'noti'],
      package_data=['LineMap.png']
      )